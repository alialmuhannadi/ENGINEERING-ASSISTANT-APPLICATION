#ifndef FUNCS_H
#define FUNCS_H

void menu_item_1(void);
void menu_item_2(void);
void menu_item_3(void);
void menu_item_4(void);

#endif